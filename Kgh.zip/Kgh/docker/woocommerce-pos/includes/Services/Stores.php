<?php

namespace WCPOS\WooCommercePOS\Services;

class Stores {

}