<?php

/**
 * Update to 1.0.0-beta.1
 *
 * Most settings are the same, perhaps gateways have changed, but users probably need to reconfigure them anyway.
 */

// Check if the old settings exist
// $old_general_settings = get_option('woocommerce_pos_settings_general');
// $old_checkout_settings = get_option('woocommerce_pos_settings_checkout');
// $old_license_settings = get_option('woocommerce_pos_settings_license');

